<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>



   <div class="page-footer"> 
    <footer class="footer-bottom"> 
     <div class="container"> 
      <div class="row"> 
       <div class="col-lg-6 col-lg-push-6 col-xs-12"> 
        <ul class="nav"> 
         <!--li class="hidden-xs"><a href="https://www.vpsmm.com/" target="_blank">小夜博客</a></li> 
         <li><a href="https://www.vpsmm.com/new.shtml" target="_blank"">VPS优惠信息</a></li>
         <li><a href="https://www.vpsmm.com/testing.shtml" target="_blank"">VPS评测</a></li> 
         <li><a href="https://www.vpsmm.com/shell.shtml" target="_blank"">常用一键包</a></li--> 
        </ul> 
       </div> 
       <div class="col-lg-6 col-lg-pull-6 col-xs-12"> 
        <p class="footer-copyright"> Copyright 2017 &copy; 泥土巢. All rights reserved. </p> 
       </div> 
      </div> 
     </div> 
    </footer> 
   </div> 
   <!-- /.page-footer --> 




</footer><!-- end #footer -->


  </div class="page-wrapper">

<script src="<?php $this->options->themeUrl('dist/js/jquery.min.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('dist/js/core.min.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('dist/js/main.js'); ?>"></script>
<script>
  var _hmt = _hmt || [];
  (function() {
    var hm = document.createElement("script");
    hm.src = "https://hm.baidu.com/hm.js?3f53fde90f546b4e4d1e0dc9655f1b7a";
    var s = document.getElementsByTagName("script")[0]; 
    s.parentNode.insertBefore(hm, s);
  })();
</script>

<script type="text/x-mathjax-config">
      MathJax.Hub.Config({
      extensions: ["tex2jax.js"],
      jax: ["input/TeX", "output/HTML-CSS"],
      tex2jax: {
        inlineMath: [ ['$','$'], ["\\(","\\)"] ],
        displayMath: [ ['$$','$$'], ["\\[","\\]"] ],
        processEscapes: true
      },
      "HTML-CSS": { availableFonts: ["TeX"] }
      });
</script>
<script src="https://cdn.bootcss.com/mathjax/2.7.5/latest.js"></script>

<?php $this->footer(); ?>


</body>
</html>
