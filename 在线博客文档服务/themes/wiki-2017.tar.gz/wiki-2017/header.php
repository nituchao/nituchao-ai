<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE HTML>
<html class="no-js">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="google-site-verification" content="Qbkts4Pou8oYVzbdyZ--WtmuvrVHL1v8JPBfQElDmAo" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title><?php $this->archiveTitle(array(
            'category'  =>  _t('分类 %s '),
            'search'    =>  _t('关键字 %s '),
            'tag'       =>  _t('标签 %s '),
            'author'    =>  _t('作者 %s ')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>

    <!-- 使用url函数转换相关路径 -->
  <!-- Styles --> 
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png"/>
  <link href="<?php $this->options->themeUrl('dist/css/core.css'); ?>" rel="stylesheet" /> 
  <link href="<?php $this->options->themeUrl('dist/css/main.css'); ?>" rel="stylesheet" /> 
  <link href="<?php $this->options->themeUrl('dist/css/global.css'); ?>" rel="stylesheet" />  
  <!--[if lt IE 9]>
  <script src="<?php $this->options->themeUrl('dist/js/selectivizr-min.js'); ?>"></script>
  <script src="<?php $this->options->themeUrl('dist/js/html5shiv.min.js'); ?>"></script>
  <script src="<?php $this->options->themeUrl('dist/js/respond.min.js'); ?>"></script>
  <![endif]--> 

    <!-- 通过自有函数输出HTML头部信息 -->
    <?php $this->header(); ?>

<!-- Baidu Tongji -->
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?8a5273d468b5b9b6fa5e296b174461da";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<!-- Baidu Tongji -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-22964808-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-22964808-2');
</script>


</head>
<body>

  <div class="page-wrapper">

   <div class="page-banner page-banner-subpage banner-resources p-b-0"> 
    <div class="container"> 
     <div class="banner-slogan banner-slogan-hero"> 
      <h1 class="docs-title slogan-title text-center"><a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a></h1> 
      <div class="banner-search"> 
       <form method="post" action="<?php $this->options->siteUrl(); ?>"> 
        <div class="input-icon"> 
         <input type="text" name="s" value="" class="form-control input-lg" placeholder="一艺之成，当尽毕生之力！" autocomplete="off" /> 
         <button type="submit" class="btn btn-link btn-icon btn-lg"><i class="zmdi zmdi-search"></i></button> 
        </div> 
       </form> 
      </div> 
     </div> 
    </div> 
   </div> 
   <!-- /.page-banner -->




    
    
